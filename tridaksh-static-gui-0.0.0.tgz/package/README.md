# @Tridaksh/Static-CLI gui
